package com.tddJunit.java;


public interface Subtract {

  long subtract(long... ops);

}
